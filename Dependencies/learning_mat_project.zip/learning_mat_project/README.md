# Inclusive Learning Mat — two ESP32s, six FSRs, two JBL speakers

A starter project for a six-target learning mat. It includes an Express backend, a browser dashboard, separate Left/Right ESP32 Arduino sketches, and a wiring diagram.

## 1. Architecture

![System architecture](docs/architecture.png)

- The browser dashboard sends a label and selected speaker list to Express.
- Express remembers the current target and last play request, then queues a command only for the selected device(s).
- Each classic ESP32 polls Express over Wi-Fi. The network worker is separate from the audio loop so HTTP delays are less likely to interrupt audio decoding.
- Each ESP32 has all six MP3 files in its own SPIFFS filesystem and streams the requested one to its assigned JBL speaker over Bluetooth Classic A2DP.
- The six pressure sensors are mapped as: **Left = Birds, Ball, Cat**; **Right = Dog, Mom, Dad**.
- When a sensor press is detected, the ESP32 posts the label and raw reading to Express. Express compares that label with the current target and the dashboard displays success or an incorrect response.

**Prototype timing note:** Selecting both speakers queues the same label for both ESP32s at nearly the same time. Wi-Fi polling and Bluetooth startup latency mean this is not sample-accurate synchronization; the two speakers may start a little apart.

## 2. Hardware and wiring

Use two **classic ESP32 Dev Module / ESP32-WROOM-32** boards, two JBL M4 speakers, six two-lead FSR pressure sensors, six 10 kΩ resistors (recommended), two USB data cables, and a breadboard or suitable prototype wiring.

**For your current resistor-free test wiring:**

![Resistor-free FSR wiring diagram](docs/wiring-resistor-free.png)

This uses the ESP32's internal pull-down and is intended only for basic press/release experiments.

**Recommended final analog wiring (when you have a breadboard and six 10 kΩ resistors):**

![Recommended analog wiring diagram](docs/wiring.png)

### Recommended analog wiring (best for the final prototype)

Use one voltage-divider circuit per sensor:

`3V3 → FSR → signal junction → 10 kΩ resistor → GND`

Connect the signal junction to the relevant ESP32 pin. The reading normally rises when pressure rises.

| Device | FSR label | ESP32 ADC pin |
|---|---|---:|
| Left | Birds | GPIO 32 |
| Left | Ball | GPIO 33 |
| Left | Cat | GPIO 34 |
| Right | Dog | GPIO 35 |
| Right | Mom | GPIO 36 |
| Right | Dad | GPIO 39 |

These are ADC1-capable input pins on the classic ESP32, so they can be read while Wi-Fi is active. GPIO 34, 35, 36, and 39 are input-only and do not have internal pull-up/down resistors; this is why the external resistor is needed for the recommended analog circuit. Use **3.3 V**, not 5 V, on sensor circuits.

Thresholds start at `1100` in analog mode. You will need to calibrate them with Serial Monitor readings for your specific FSRs. Change `PRESS_THRESHOLD` and, if needed, `RELEASE_HYSTERESIS` in each sketch.

### Current resistor-free option (default in the firmware)

If you do not have a breadboard or resistors yet, the sketches default to:

```cpp
#define FSR_USE_EXTERNAL_RESISTORS 0
```

Connect one FSR lead to 3V3 and the other lead to its assigned GPIO (no external resistor and no direct GND connection on the sensor). The firmware uses `INPUT_PULLDOWN` for a basic digital press/release signal. Pins used in this mode are:

- Left: GPIO 32, 33, 25 → Birds, Ball, Cat
- Right: GPIO 26, 27, 14 → Dog, Mom, Dad

This resistor-free mode is only a basic digital trigger; it does not provide reliable force values. Depending on the FSR and wiring, the GPIO may not rise high enough when pressed, or the input may be noisy. If a sensor stays pressed or never triggers, switch to the recommended analog circuit with a resistor divider.

When your breadboard and six 10 kΩ resistors are ready, change `FSR_USE_EXTERNAL_RESISTORS` to `1` in **both** sketches and use the analog pin map in the table above. Do not use GPIO 34/35/36/39 for the resistor-free mode because those pins have no internal pull-up/down resistors.

## 3. Audio files on each ESP32

Both ESP32s need their own copy of all six files, because either speaker may be selected for any word. Use these exact lowercase filenames:

```text
birds.mp3
ball.mp3
cat.mp3
dog.mp3
mom.mp3
dad.mp3
```

Your MP3 clips should be short, mono or stereo, and encoded in a format supported by the installed Helix MP3 decoder. Keep the combined size below the SPIFFS partition size (your current default partition log showed about 1.4 MB available).

### Uploading SPIFFS

The `.bat` uploader you used earlier reports `Data dir: ./data`, which means it is using a `data` directory relative to its own configured working folder. For each ESP32:

1. Copy the six MP3 files into the uploader's **actual** `data` folder, or update the uploader config using the exact data-folder setting supported by that uploader version.
2. Close Arduino Serial Monitor / Serial Plotter to release COM port.
3. Run the SPIFFS uploader `.bat` and make sure the output lists all six expected files (not only `/test.mp3` or `/signal.txt`).
4. Wait for a successful flash/upload message.
5. Repeat for the other ESP32. Each board stores files separately.

Do **not** run the filesystem uploader and Arduino IDE Serial Monitor on the same COM port at the same time.

## 4. Libraries and board

In Arduino IDE Library Manager install:

- **Audio Tools** by Phil Schatzmann
- **ESP32-A2DP** by Phil Schatzmann
- **arduino-libhelix** (MP3 decoder)
- **ArduinoJson** (6.x or compatible 7.x API)

Select **ESP32 Dev Module** for a classic ESP32. The Bluetooth A2DP source approach does not work on ESP32-C3/S3 boards because they do not support Bluetooth Classic A2DP. Reference: [ESP32-A2DP project and examples](https://github.com/pschatzmann/ESP32-A2DP) and [AudioTools A2DP player example](https://github.com/pschatzmann/arduino-audio-tools/tree/main/examples/examples-communication/a2dp).

## 5. Start the Express backend

Install Node.js 18 or newer. In a terminal:

```bash
cd server
npm install
npm start
```

Open `http://localhost:3000` in your browser. The health endpoint is `http://localhost:3000/health`.

The server binds to `0.0.0.0` so ESP32s on the same LAN can reach it. To discover the computer's IPv4 address on Windows, run `ipconfig` and use the Wi-Fi adapter's IPv4 address, for example `192.168.1.25`.

## 6. Configure each firmware sketch

Open `firmware/ESP32_Left/ESP32_Left.ino` and `firmware/ESP32_Right/ESP32_Right.ino` separately. In **both** files, set:

```cpp
const char* WIFI_SSID = "your-2.4-GHz-WiFi-name";
const char* WIFI_PASSWORD = "your-WiFi-password";
const char* API_BASE_URL = "http://192.168.1.25:3000"; // replace with server PC's LAN IP
const char* DEVICE_API_KEY = "local-dev-token-change-before-deployment";
```

The token must match the server's `DEVICE_API_KEY` environment variable. For a first local test, the server defaults to the same development token shown above. **Change it before deployment.**

Upload the Left sketch to the physical left ESP32 and the Right sketch to the physical right ESP32. Use Serial Monitor at 115200 baud. You should see Wi-Fi connection information, SPIFFS file checks, Bluetooth initialization, and periodic status logs.

Both ESP32s and the server computer must be able to reach each other on the same LAN. Use a 2.4 GHz Wi-Fi network for the ESP32. Allow inbound TCP port 3000 through your PC firewall for a local LAN test if Windows prompts you.

## 7. Pair each ESP32 with its own JBL M4

The firmware uses the Bluetooth name `M4` by default. If your speaker advertises `JBL M4`, change `BT_SPEAKER_NAME` in the matching sketch to the exact advertised name.

**Important if the two speakers have the same Bluetooth name:** Pair/commission the left board with only the left speaker powered on, then commission the right board with only the right speaker powered on. Test each speaker separately before enabling both. If the Bluetooth source ever connects to the wrong unit after a reboot, the two identical names are ambiguous; the robust fix is selecting each speaker by its Bluetooth MAC address (or using unique advertised names, if the model supports renaming). A name alone is not a guaranteed unique identifier.

Bluetooth speaker pairing may require the speaker to be in pairing mode. Disconnect the speaker from a phone while commissioning.

## 8. Dashboard behaviour

- Choose a sound button. The browser sends `POST /api/play` with `label` and the checked speaker side(s).
- Both speaker checkboxes may be selected. Only the selected ESP32s receive the audio command.
- **Repeat last audio** sends the same `POST /api/play` request shape again using the last label and speaker selection saved in browser and server memory, even if the checkboxes have changed since then.
- The selected audio label becomes the current expected target. When the matching physical sensor is pressed, the dashboard displays **Success!**. An unmatched press shows **Try again**.
- Success and attempts, command queues, device online state, and recent events are stored in server memory.

**Memory limitation:** Since this is a basic prototype with no database, state and queued commands reset if the Node server restarts. Add persistent storage if you need durable session history.

## 9. API overview

| Endpoint | Purpose |
|---|---|
| `GET /health` | Server health check |
| `GET /api/state` | Dashboard state, device status, recent events |
| `POST /api/play` | `{ "label": "mom", "speakers": ["left"] }` |
| `GET /api/device/:side/command` | Device-authenticated command poll; `side` is `left` or `right` |
| `POST /api/device/:side/sensor` | Device-authenticated sensor event `{ "label": "mom", "raw": 2380 }` |

Device requests must send `X-Device-Key`. Requests to `/api/play` are intentionally unauthenticated for local prototyping; add user authentication before exposing the dashboard publicly.

## 10. Deploying to Oracle Cloud later

The firmware starter is configured for **plain HTTP on a trusted local network**. Do not expose this version directly to the public internet with a device token over HTTP. For cloud deployment, put Express behind HTTPS (for example, a reverse proxy with a valid TLS certificate) and update the ESP32 firmware to validate the server's CA certificate using `WiFiClientSecure`; do not use `setInsecure()` in a real deployment. Also add authentication for the browser dashboard, rate limiting, and durable storage as needed.

## Debugging checklist

- `[FS ERROR] Missing ...`: upload all six MP3 files to that board's SPIFFS.
- `[FATAL] SPIFFS mount failed`: verify the partition scheme and filesystem image.
- `[Wi-Fi WARN]`: check SSID/password, 2.4 GHz availability, and router/client isolation.
- `[HTTP ERROR] ... 401`: the device token differs from the server token.
- `[HTTP ERROR] ... connection refused`: the API base URL is wrong or the server/firewall is unavailable.
- `[SENSOR] PRESS` but dashboard does not change: check device auth and `/api/device/<side>/sensor` requests in server logs.
- Sensor always pressed/not pressed: check FSR wiring; with analog mode, verify 3V3→FSR→GPIO node and 10 kΩ from node to GND; then tune thresholds.
- No Bluetooth audio: confirm a classic ESP32 board, exact speaker name, speaker pairing mode, and the library logs. Test with only the assigned speaker powered on.
