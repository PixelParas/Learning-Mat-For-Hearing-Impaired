/*
 * Inclusive Learning Mat - RIGHT node
 * Classic ESP32 Dev Module required for Bluetooth Classic A2DP.
 * Files expected in SPIFFS root: birds.mp3, ball.mp3, cat.mp3, dog.mp3, mom.mp3, dad.mp3
 * See ../../README.md before uploading.
 */
#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <SPIFFS.h>
#include <ArduinoJson.h>
#include "AudioTools.h"
#include "AudioTools/Communication/A2DPStream.h"
#include "AudioTools/Disk/AudioSourceSPIFFS.h"
#include "AudioTools/AudioCodecs/CodecMP3Helix.h"

// ---------- CHANGE THESE VALUES ----------
const char* WIFI_SSID = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
// Use the computer/server LAN IP during local tests, e.g. http://192.168.1.25:3000
const char* API_BASE_URL = "http://192.168.1.100:3000";
// Must match DEVICE_API_KEY on the Express server.
const char* DEVICE_API_KEY = "local-dev-token-change-before-deployment";
const char* DEVICE_ID = "right";
const char* BT_SPEAKER_NAME = "M4";

// 1 = robust analog voltage divider: one 10k resistor per FSR.
// 0 = temporary digital trigger using the ESP32 internal pull-down (less reliable).
#define FSR_USE_EXTERNAL_RESISTORS 0

#if FSR_USE_EXTERNAL_RESISTORS
const uint8_t SENSOR_PINS[3] = {35, 36, 39}; // ADC1 pins; input-only, ideal for analog reads
#else
const uint8_t SENSOR_PINS[3] = {26, 27, 14}; // internal pull-down; no analog force measurement
#endif
const char* SENSOR_LABELS[3] = {"dog", "mom", "dad"};
const uint16_t PRESS_THRESHOLD[3] = {1100, 1100, 1100}; // calibrate in Serial Monitor
const uint16_t RELEASE_HYSTERESIS = 150;
const uint32_t PRESS_DEBOUNCE_MS = 60;
const uint32_t RELEASE_DEBOUNCE_MS = 100;
const uint32_t COMMAND_POLL_MS = 250;

struct AudioCommand { uint32_t id; char label[16]; };
struct SensorEvent { char label[16]; uint16_t raw; };
QueueHandle_t commandQueue = nullptr;
QueueHandle_t sensorQueue = nullptr;

AudioSourceSPIFFS source("/", "mp3");
A2DPStream bluetoothOut;
MP3DecoderHelix mp3Decoder;
AudioPlayer player(source, bluetoothOut, mp3Decoder);
bool audioReady = false;
bool audioFilesReady = false;

bool sensorLatched[3] = {false, false, false};
uint32_t pressCandidateAt[3] = {0, 0, 0};
uint32_t releaseCandidateAt[3] = {0, 0, 0};
uint32_t lastStatusAt = 0;
uint16_t lastRawValues[3] = {0, 0, 0};

const char* pathForLabel(const char* label) {
  if (strcmp(label, "birds") == 0) return "/birds.mp3";
  if (strcmp(label, "ball") == 0) return "/ball.mp3";
  if (strcmp(label, "cat") == 0) return "/cat.mp3";
  if (strcmp(label, "dog") == 0) return "/dog.mp3";
  if (strcmp(label, "mom") == 0) return "/mom.mp3";
  if (strcmp(label, "dad") == 0) return "/dad.mp3";
  return nullptr;
}

uint16_t readSensorRaw(uint8_t index) {
#if FSR_USE_EXTERNAL_RESISTORS
  return (uint16_t)analogRead(SENSOR_PINS[index]);
#else
  return digitalRead(SENSOR_PINS[index]) == LOW ? 0 : 4095;
#endif
}

bool sensorPressureCondition(uint8_t index, uint16_t raw) {
#if FSR_USE_EXTERNAL_RESISTORS
  return raw >= PRESS_THRESHOLD[index];
#else
  (void)index;
  return raw == 4095;
#endif
}

bool sensorReleaseCondition(uint8_t index, uint16_t raw) {
#if FSR_USE_EXTERNAL_RESISTORS
  const uint16_t releasePoint = PRESS_THRESHOLD[index] > RELEASE_HYSTERESIS
      ? PRESS_THRESHOLD[index] - RELEASE_HYSTERESIS : 0;
  return raw < releasePoint;
#else
  (void)index;
  return raw == 0;
#endif
}

void enqueueSensorEvent(uint8_t index, uint16_t raw) {
  if (!sensorQueue) return;
  SensorEvent event{};
  strlcpy(event.label, SENSOR_LABELS[index], sizeof(event.label));
  event.raw = raw;
  if (xQueueSend(sensorQueue, &event, 0) != pdTRUE) {
    Serial.printf("[WARN] Sensor event queue full; dropped %s event\n", event.label);
  } else {
    Serial.printf("[SENSOR] PRESS label=%s raw=%u\n", event.label, raw);
  }
}

void playLabel(const char* label, uint32_t commandId) {
  const char* path = pathForLabel(label);
  if (!path) {
    Serial.printf("[ERROR] Unknown audio label in command: %s\n", label);
    return;
  }
  if (!audioReady) {
    Serial.println("[ERROR] Audio system is not ready.");
    return;
  }
  if (!SPIFFS.exists(path)) {
    Serial.printf("[ERROR] Missing audio file: %s\n", path);
    return;
  }
  Serial.printf("[AUDIO] Command %lu: playing %s (%s)\n",
                (unsigned long)commandId, label, path);
  player.stop();
  if (!player.setPath(path)) {
    Serial.printf("[ERROR] player.setPath failed for %s\n", path);
    return;
  }
  player.play();
}

void deliverQueuedCommands() {
  if (!commandQueue) return;
  AudioCommand cmd{};
  if (xQueueReceive(commandQueue, &cmd, 0) == pdTRUE) playLabel(cmd.label, cmd.id);
}

void reportSensorEvent(const SensorEvent& event) {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.printf("[WARN] Can't report %s: Wi-Fi disconnected\n", event.label);
    return;
  }
  HTTPClient http;
  String url = String(API_BASE_URL) + "/api/device/" + DEVICE_ID + "/sensor";
  http.setConnectTimeout(1200);
  http.setTimeout(1500);
  if (!http.begin(url)) {
    Serial.println("[HTTP] Failed to initialize sensor POST.");
    return;
  }
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-Device-Key", DEVICE_API_KEY);
  StaticJsonDocument<192> doc;
  doc["label"] = event.label;
  doc["raw"] = event.raw;
  String body;
  serializeJson(doc, body);
  int code = http.POST(body);
  if (code >= 200 && code < 300) {
    Serial.printf("[HTTP] Sensor event accepted (%d): %s\n", code, event.label);
  } else {
    Serial.printf("[HTTP ERROR] Sensor POST code=%d body=%s\n", code, http.getString().c_str());
  }
  http.end();
}

void pollCommand() {
  if (WiFi.status() != WL_CONNECTED) return;
  HTTPClient http;
  String url = String(API_BASE_URL) + "/api/device/" + DEVICE_ID + "/command";
  http.setConnectTimeout(900);
  http.setTimeout(1000);
  if (!http.begin(url)) {
    Serial.println("[HTTP] Failed to initialize command poll.");
    return;
  }
  http.addHeader("X-Device-Key", DEVICE_API_KEY);
  int code = http.GET();
  if (code == 200) {
    StaticJsonDocument<512> doc;
    DeserializationError err = deserializeJson(doc, http.getString());
    if (err) {
      Serial.printf("[JSON ERROR] Command parse failed: %s\n", err.c_str());
    } else if (!doc["command"].isNull()) {
      JsonObject command = doc["command"].as<JsonObject>();
      AudioCommand queued{};
      queued.id = command["id"] | 0;
      const char* label = command["label"] | "";
      strlcpy(queued.label, label, sizeof(queued.label));
      if (pathForLabel(queued.label) == nullptr) {
        Serial.printf("[ERROR] Server sent unknown label: %s\n", queued.label);
      } else if (xQueueSend(commandQueue, &queued, 0) != pdTRUE) {
        Serial.println("[WARN] Audio command queue full; command dropped.");
      } else {
        Serial.printf("[HTTP] Received command id=%lu label=%s\n", (unsigned long)queued.id, queued.label);
      }
    }
  } else if (code < 0) {
    Serial.printf("[HTTP ERROR] Poll failed: %s\n", HTTPClient::errorToString(code).c_str());
  } else if (code != 204) {
    Serial.printf("[HTTP ERROR] Command poll returned HTTP %d\n", code);
  }
  http.end();
}

void networkWorker(void* parameter) {
  (void)parameter;
  uint32_t lastPollAt = 0;
  uint32_t lastWifiRetryAt = 0;
  for (;;) {
    if (WiFi.status() != WL_CONNECTED) {
      if (millis() - lastWifiRetryAt >= 5000) {
        lastWifiRetryAt = millis();
        Serial.println("[Wi-Fi] Disconnected; retrying...");
        WiFi.reconnect();
      }
      vTaskDelay(pdMS_TO_TICKS(200));
      continue;
    }
    SensorEvent event{};
    if (xQueueReceive(sensorQueue, &event, 0) == pdTRUE) reportSensorEvent(event);
    if (millis() - lastPollAt >= COMMAND_POLL_MS) {
      lastPollAt = millis();
      pollCommand();
    }
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

void setup() {
  Serial.begin(115200);
  delay(700);
  Serial.println("\n======================================");
  Serial.println(" Learning Mat / RIGHT ESP32 booting");
  Serial.println("======================================");

  commandQueue = xQueueCreate(8, sizeof(AudioCommand));
  sensorQueue = xQueueCreate(12, sizeof(SensorEvent));
  if (!commandQueue || !sensorQueue) {
    Serial.println("[FATAL] Could not allocate FreeRTOS queues.");
    while (true) delay(1000);
  }

#if FSR_USE_EXTERNAL_RESISTORS
  for (uint8_t i = 0; i < 3; i++) {
    pinMode(SENSOR_PINS[i], INPUT);
    analogSetPinAttenuation(SENSOR_PINS[i], ADC_11db);
  }
  Serial.println("[SENSOR] Analog mode: use 10k resistor divider on every FSR.");
#else
  for (uint8_t i = 0; i < 3; i++) pinMode(SENSOR_PINS[i], INPUT_PULLDOWN);
  Serial.println("[SENSOR] Digital fallback mode: sensor between 3V3 and GPIO; internal pull-down enabled.");
  Serial.println("[WARN] Digital FSR triggering is less repeatable than analog mode.");
#endif

  Serial.println("[FS] Mounting SPIFFS without formatting...");
  if (!SPIFFS.begin(false)) {
    Serial.println("[FATAL] SPIFFS mount failed. Upload filesystem image first.");
  } else {
    const char* files[] = {"/birds.mp3", "/ball.mp3", "/cat.mp3", "/dog.mp3", "/mom.mp3", "/dad.mp3"};
    uint8_t found = 0;
    for (const char* filePath : files) {
      if (SPIFFS.exists(filePath)) {
        File file = SPIFFS.open(filePath, FILE_READ);
        Serial.printf("[FS] OK %-12s %u bytes\n", filePath, file ? (unsigned int)file.size() : 0);
        if (file) file.close();
        found++;
      } else Serial.printf("[FS ERROR] Missing %s\n", filePath);
    }
    if (found == 6) {
      audioFilesReady = true;
      Serial.println("[FS] All six audio files are present.");
    } else {
      Serial.printf("[AUDIO ERROR] Found %u/6 audio files. Re-upload all six files to SPIFFS.\n", found);
    }
  }

  Serial.printf("[Wi-Fi] Joining SSID: %s\n", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  uint32_t wifiStart = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - wifiStart < 15000) {
    delay(300);
    Serial.print('.');
  }
  Serial.println();
  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("[Wi-Fi] Connected; IP=%s RSSI=%d dBm\n", WiFi.localIP().toString().c_str(), WiFi.RSSI());
  } else Serial.println("[Wi-Fi WARN] Not connected yet; background worker will retry.");

  Serial.printf("[BT] Starting A2DP source; target speaker name='%s'\n", BT_SPEAKER_NAME);
  auto btConfig = bluetoothOut.defaultConfig(TX_MODE);
  btConfig.name = BT_SPEAKER_NAME;
  btConfig.auto_reconnect = true;
  btConfig.silence_on_nodata = true;
  bluetoothOut.begin(btConfig);
  Serial.println("[BT] A2DP initialized. Watch logs for speaker connection state.");

  // Initialize the player only after the Bluetooth output stream has started.
  if (audioFilesReady) {
    AudioToolsLogger.begin(Serial, AudioToolsLogLevel::Warning);
    player.setAutoNext(false);
    player.setVolume(0.9);
    player.setDelayIfOutputFull(0);
    audioReady = player.begin(0, false); // Initialize inactive; do not auto-play on boot.
    if (audioReady) {
      Serial.println("[AUDIO] Player initialized; waiting for backend command.");
    } else {
      Serial.println("[AUDIO ERROR] AudioPlayer begin() failed.");
    }
  }

  xTaskCreatePinnedToCore(networkWorker, "networkWorker", 8192, nullptr, 1, nullptr, 0);
  Serial.printf("[SYSTEM] Device=%s; sensor labels=Dog, Mom, Dad\n", DEVICE_ID);
  Serial.println("[SYSTEM] Ready. Keep Serial Monitor at 115200 baud.");
}

void loop() {
  if (audioReady) player.copy();
  deliverQueuedCommands();
  const uint32_t now = millis();
  for (uint8_t i = 0; i < 3; i++) {
    const uint16_t raw = readSensorRaw(i);
    lastRawValues[i] = raw;
    if (!sensorLatched[i]) {
      if (sensorPressureCondition(i, raw)) {
        if (pressCandidateAt[i] == 0) pressCandidateAt[i] = now;
        if (now - pressCandidateAt[i] >= PRESS_DEBOUNCE_MS) {
          sensorLatched[i] = true;
          pressCandidateAt[i] = 0;
          releaseCandidateAt[i] = 0;
          enqueueSensorEvent(i, raw);
        }
      } else pressCandidateAt[i] = 0;
    } else {
      if (sensorReleaseCondition(i, raw)) {
        if (releaseCandidateAt[i] == 0) releaseCandidateAt[i] = now;
        if (now - releaseCandidateAt[i] >= RELEASE_DEBOUNCE_MS) {
          sensorLatched[i] = false;
          releaseCandidateAt[i] = 0;
          Serial.printf("[SENSOR] RELEASE label=%s raw=%u\n", SENSOR_LABELS[i], raw);
        }
      } else releaseCandidateAt[i] = 0;
    }
  }

  if (now - lastStatusAt >= 3000) {
    lastStatusAt = now;
    Serial.printf("[STATUS] WiFi=%s RSSI=%d dBm | AudioReady=%s | Heap=%u\n",
      WiFi.status() == WL_CONNECTED ? "connected" : "disconnected",
      WiFi.status() == WL_CONNECTED ? WiFi.RSSI() : 0,
      audioReady ? "yes" : "no",
      (unsigned int)ESP.getFreeHeap());
    Serial.printf("[RAW] %s=%u, %s=%u, %s=%u | threshold=%u/%u/%u\n",
      SENSOR_LABELS[0], lastRawValues[0], SENSOR_LABELS[1], lastRawValues[1],
      SENSOR_LABELS[2], lastRawValues[2], PRESS_THRESHOLD[0], PRESS_THRESHOLD[1], PRESS_THRESHOLD[2]);
  }
  delay(1);
}
